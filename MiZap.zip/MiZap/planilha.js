/*
 * Alexandria no WhatsApp — Planilha de contatos + importação + disparo
 *
 * Esta tela NUNCA envia mensagem. Ela só monta a campanha no servidor (fila do Disparo),
 * que o trabalhador do n8n envia devagar, com as regras de bloqueio.
 */
const $ = (id) => document.getElementById(id);
const bg = (m) => new Promise((ok) => chrome.runtime.sendMessage(m, (r) => ok(r || { ok: false, erro: "sem resposta" })));
const rpc = async (fn, args) => { const r = await bg({ tipo: "rpc", fn, args }); if (!r.ok) throw new Error(r.erro); return r.dados; };
const el = (tag, props = {}, ...filhos) => { const e = Object.assign(document.createElement(tag), props); e.append(...filhos.filter((f) => f != null)); return e; };
const aviso = (alvo, t, tipo) => $(alvo).replaceChildren(t ? el("div", { className: "msg" + (tipo ? " " + tipo : ""), textContent: t }) : "");

const BLOQ = {
  pediu_sair: "pediu SAIR", conversa_ativa: "conversou há menos de 3 dias", disparo_recente: "recebeu disparo há menos de 15 dias",
  demo: "demonstração", sem_contato: "sem telefone", telefone_invalido: "telefone inválido",
  funil_Vendido: "vendido", funil_Perdido: "perdido"
};
const motivo = (m) => BLOQ[m] || (m || "").replace(/^status_/, "status ").replace(/^pausado_/, "pausado ").replace(/_/g, " ");

let dados = { linhas: [], grupos: [], etapas: [], corretores: [], sou_admin: false, eu: "" };
let etapasInfo = null;                                // etapas editáveis (ext_etapas_listar); null = etapas.sql ainda não rodado
const rotulo = (k) => ((etapasInfo || []).find((e) => e.chave === k) || {}).nome || k;
let empreendimentos = [];
const selecionados = new Set();
let ordem = { campo: "ultima", desc: true };
let importacao = null;
const Q = new URLSearchParams(location.search);
const EMBED = Q.has("embed");
if (EMBED) document.body.classList.add("embed");
let vista = Q.get("v") === "funil" ? "funil" : "tabela";
let primeiraCarga = true;

// ---------- carregar ----------
async function carregar() {
  aviso("topo", "Carregando…");
  try {
    const [d, emps, qs, ets] = await Promise.all([
      rpc("ext_planilha_listar", { p_filtro: { empreendimento: $("fEmp").value, etapa: $("fEtapa").value, busca: $("fBusca").value } }),
      rpc("ext_empreendimentos", {}),
      rpc("ext_quadros_listar", {}).catch(() => null),   // null = quadros.sql ainda não rodado
      rpc("ext_etapas_listar", {}).catch(() => null)     // null = etapas.sql ainda não rodado
    ]);
    dados = d; empreendimentos = emps || []; quadros = qs; etapasInfo = ets;
    if (etapasInfo) dados.etapas = etapasInfo.map((e) => e.chave);
    montarQuadros();
    $("quem").textContent = (d.sou_admin ? "admin · " : "") + d.eu;
    montarFiltros(); desenhar(); aviso("topo", "");
    if (primeiraCarga) { primeiraCarga = false; abrirPeloLink(); }
  } catch (e) {
    aviso("topo", e.message === "sem_login" ? EMBED ? "Entre pelo botão Conta, no menu da esquerda, e clique em ⟳." : "Entre pelo ícone da extensão (aba Conta) e atualize esta página." : e.message, "erro");
  }
}

function montarFiltros() {
  const nomes = new Set([...empreendimentos, ...dados.grupos.map((g) => g.empreendimento).filter(Boolean)]);
  const fe = $("fEmp"), atual = fe.value;
  fe.replaceChildren(new Option("Todos os empreendimentos", ""), new Option("(sem empreendimento)", "__sem__"),
    ...[...nomes].sort((a, b) => a.localeCompare(b)).map((n) => new Option(n, n)));
  fe.value = atual;
  $("listaEmp").replaceChildren(...[...nomes].sort().map((n) => el("option", { value: n })));
  const ft = $("fEtapa"), et = ft.value;
  ft.replaceChildren(new Option("Todas as etapas", ""), ...dados.etapas.map((e) => new Option(rotulo(e), e)));
  ft.value = et;
  $("grupos").replaceChildren(...dados.grupos.map((g) => {
    const v = g.empreendimento || "__sem__";
    const c = el("span", { className: "chip" + ($("fEmp").value === v ? " on" : ""), textContent: (g.empreendimento || "sem empreendimento") + " · " + g.total });
    c.onclick = () => { $("fEmp").value = $("fEmp").value === v ? "" : v; carregar(); };
    return c;
  }));
}

function visiveis() {
  let l = dados.linhas;
  if ($("fSoPode").checked) l = l.filter((x) => !x.bloqueio);
  const { campo, desc } = ordem;
  return [...l].sort((a, b) => {
    const x = (a[campo] ?? "") + "", y = (b[campo] ?? "") + "";
    return (desc ? -1 : 1) * x.localeCompare(y, "pt-BR", { numeric: true });
  });
}

const fmtTel = (t) => { const d = (t || "").replace(/^55/, ""); return d.length === 11 ? `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}` : d.length === 10 ? `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}` : t; };
const fmtData = (s) => s ? new Date(s).toLocaleDateString("pt-BR") : "";

async function salvar(campoEl, linha, campo, valor) {
  campoEl.classList.remove("salvo", "falha");
  try {
    await rpc("ext_planilha_salvar", { p_telefone: linha.telefone, p_campo: campo, p_valor: valor });
    if (campo !== "nota") linha[campo] = valor; else linha.nota = valor;
    campoEl.classList.add("salvo"); setTimeout(() => campoEl.classList.remove("salvo"), 1200);
    return true;
  } catch (e) { campoEl.classList.add("falha"); campoEl.title = e.message; aviso("topo", e.message, "erro"); return false; }
}

function desenhar() {
  if (vista === "funil") return desenharFunil();
  const lista = visiveis();
  $("linhas").replaceChildren(...lista.map((x) => {
    const tr = el("tr", { className: selecionados.has(x.telefone) ? "sel" : "" });
    const ck = el("input", { type: "checkbox", checked: selecionados.has(x.telefone) });
    ck.onchange = () => { ck.checked ? selecionados.add(x.telefone) : selecionados.delete(x.telefone); tr.className = ck.checked ? "sel" : ""; contarSel(); };

    const emp = el("input", { value: x.empreendimento || "", placeholder: "—" }); emp.setAttribute("list", "listaEmp");
    emp.onchange = () => salvar(emp, x, "empreendimento", emp.value.trim());

    const et = el("select", {}, ...dados.etapas.map((e) => new Option(rotulo(e), e)));
    et.value = x.etapa || "Novo"; et.onchange = () => salvar(et, x, "etapa", et.value);

    let dono;
    if (dados.sou_admin) {
      dono = el("select", {}, new Option("(sem dono)", ""), ...dados.corretores.map((c) => new Option(c.nome, c.id)));
      dono.value = x.dono || ""; dono.onchange = () => salvar(dono, x, "dono", dono.value);
    } else dono = el("span", { textContent: x.dono || "" });

    const nota = el("input", { value: x.nota || "", placeholder: "escreva e aperte Enter", title: x.nota || "" });
    nota.onkeydown = async (e) => { if (e.key === "Enter" && nota.value.trim() && nota.value !== x.nota) await salvar(nota, x, "nota", nota.value.trim()); };

    const ro = (t) => el("td", { className: "ro", textContent: t || "" });
    const disp = x.bloqueio ? el("span", { className: "nao", textContent: motivo(x.bloqueio) }) : el("span", { className: "ok", textContent: "pode" });
    tr.append(el("td", {}, ck), el("td", { textContent: x.nome || "" }), el("td", { textContent: fmtTel(x.telefone) }),
      el("td", {}, emp), el("td", {}, et), el("td", {}, dono), el("td", {}, nota),
      ro(x.renda), ro(x.fgts), ro(x.interesse), ro(x.temperatura),
      el("td", { className: "ro res", textContent: x.resumo || "" }), el("td", {}, disp), ro(fmtData(x.ultima)));
    return tr;
  }));
  contarSel();
  if (!lista.length) aviso("topo", "Nenhum contato com esse filtro.");
}
// ---------- Funil / Quadros (cartões em colunas; arraste pra mover) ----------
const COR_ETAPA = ["#00a884", "#1d9bf0", "#7c5cff", "#ff7a00", "#16a34a", "#b42318", "#e8459b", "#667781"];
const corEtapa = (e) => { const f = (etapasInfo || []).find((x) => x.chave === e); if (f) return f.cor; const i = dados.etapas.indexOf(e); return COR_ETAPA[(i < 0 ? 7 : i) % COR_ETAPA.length]; };
let arrastando = null;
let quadros = null;                                   // meus quadros (ext_quadros_listar)
let quadroSel = localStorage.getItem("alex_quadro") || "etapas";   // "etapas" | "emp" | id do quadro
const chaveTel = (t) => { let d = String(t || "").replace(/\D/g, ""); if (d.length >= 12 && d.startsWith("55")) d = d.slice(2); return d.length >= 10 ? d.slice(0, 2) + d.slice(-8) : null; };
const empsExtras = () => { try { return JSON.parse(localStorage.getItem("alex_emps_extras") || "[]"); } catch (e) { return []; } };

function abrirConversa(tel) {
  if (EMBED) window.parent.postMessage({ alexandria: "abrirConversa", telefone: tel }, "https://web.whatsapp.com");
  else window.open("https://web.whatsapp.com/send?phone=" + (tel.length <= 11 ? "55" + tel : tel), "_blank");
}
const quadroAtual = () => (quadros || []).find((q) => String(q.id) === String(quadroSel));

function montarQuadros() {
  const s = $("fQuadro");
  const ops = [new Option("Etapas do funil", "etapas"), new Option("Por empreendimento", "emp")];
  for (const q of quadros || []) ops.push(new Option("▦ " + q.nome, String(q.id)));
  ops.push(new Option(quadros ? "+ Criar quadro novo…" : "+ Criar quadro (rode o quadros.sql)", "novo"));
  s.replaceChildren(...ops);
  if (!["etapas", "emp"].includes(quadroSel) && !quadroAtual()) quadroSel = "etapas";
  s.value = quadroSel;
  const meu = !!quadroAtual();
  $("qRenomear").hidden = $("qApagar").hidden = !meu;
  $("qNovaCol").hidden = quadroSel === "etapas" && !(etapasInfo && dados.sou_admin);
  $("qDica").textContent = meu ? "Arraste da Entrada pra uma coluna. Pra tirar do quadro, arraste de volta pra Entrada."
    : quadroSel === "emp" ? "Arrastar muda o empreendimento do contato." : "Arrastar muda a etapa do funil." + (etapasInfo && dados.sou_admin ? " Use os botões do topo de cada coluna pra editar as etapas." : "");
}
$("fQuadro").onchange = async () => {
  if ($("fQuadro").value === "novo") {
    if (!quadros) { $("fQuadro").value = quadroSel; return aviso("topo", "Rode o quadros.sql no Supabase e clique em Atualizar.", "erro"); }
    const nome = (prompt("Nome do quadro (ex.: Laguna, Vista Plaza, Retornos da semana):") || "").trim();
    if (!nome) { $("fQuadro").value = quadroSel; return; }
    try { const id = await rpc("ext_quadro_salvar", { p_id: null, p_nome: nome }); quadroSel = String(id); await recarregarQuadros(); }
    catch (e) { aviso("topo", e.message, "erro"); }
  } else quadroSel = $("fQuadro").value;
  localStorage.setItem("alex_quadro", quadroSel);
  montarQuadros(); desenharFunil();
};
async function recarregarQuadros() { quadros = await rpc("ext_quadros_listar", {}); montarQuadros(); desenharFunil(); }
$("qRenomear").onclick = async () => {
  const q = quadroAtual(); if (!q) return;
  const nome = (prompt("Novo nome do quadro:", q.nome) || "").trim(); if (!nome || nome === q.nome) return;
  try { await rpc("ext_quadro_salvar", { p_id: q.id, p_nome: nome }); await recarregarQuadros(); } catch (e) { aviso("topo", e.message, "erro"); }
};
$("qApagar").onclick = async () => {
  const q = quadroAtual(); if (!q) return;
  if (!confirm(`Apagar o quadro "${q.nome}"? Os contatos não são apagados, só saem do quadro.`)) return;
  try { await rpc("ext_quadro_apagar", { p_id: q.id }); quadroSel = "etapas"; localStorage.setItem("alex_quadro", quadroSel); await recarregarQuadros(); }
  catch (e) { aviso("topo", e.message, "erro"); }
};
$("qNovaCol").onclick = async () => {
  const nome = (prompt(quadroSel === "emp" ? "Nome do empreendimento (ex.: Laguna):" : quadroSel === "etapas" ? "Nome da nova etapa (ex.: Retorno):" : "Nome da coluna:") || "").trim();
  if (!nome) return;
  if (quadroSel === "etapas") {
    try { await rpc("ext_etapa_salvar", { p_id: null, p_nome: nome, p_cor: COR_ETAPA[etapasInfo.length % 7] }); await carregar(); }
    catch (e) { aviso("topo", erroEtapa(e.message), "erro"); }
    return;
  }
  if (quadroSel === "emp") {
    const ex = empsExtras(); if (!ex.includes(nome)) ex.push(nome);
    localStorage.setItem("alex_emps_extras", JSON.stringify(ex)); return desenharFunil();
  }
  const q = quadroAtual(); if (!q) return;
  try { await rpc("ext_coluna_salvar", { p_quadro: q.id, p_id: null, p_nome: nome, p_cor: COR_ETAPA[q.colunas.length % 7], p_ordem: null }); await recarregarQuadros(); }
  catch (e) { aviso("topo", e.message, "erro"); }
};

// monta as colunas do quadro escolhido: [{ key, nome, cor, ferramentas, itens }]
function colunasDoQuadro(lista) {
  const q = quadroAtual();
  if (q) {
    const onde = new Map(q.cartoes.map((k) => [k.chave, String(k.coluna)]));
    const cols = [{ key: "", nome: "Entrada", cor: "#8696a0", entrada: true, itens: [] },
      ...q.colunas.map((c) => ({ key: String(c.id), nome: c.nome, cor: c.cor, coluna: c, itens: [] }))];
    const porKey = new Map(cols.map((c) => [c.key, c]));
    for (const x of lista) { const k = onde.get(chaveTel(x.telefone)) || ""; (porKey.get(k) || cols[0]).itens.push(x); }
    return cols;
  }
  if (quadroSel === "emp") {
    const nomes = [...new Set([...empreendimentos, ...dados.grupos.map((g) => g.empreendimento).filter(Boolean), ...empsExtras()])].sort((a, b) => a.localeCompare(b));
    const cols = [{ key: "", nome: "Sem empreendimento", cor: "#8696a0", itens: [] }, ...nomes.map((n, i) => ({ key: n, nome: n, cor: COR_ETAPA[i % 7], itens: [] }))];
    const porKey = new Map(cols.map((c) => [c.key.toLowerCase(), c]));
    for (const x of lista) (porKey.get((x.empreendimento || "").toLowerCase()) || cols[0]).itens.push(x);
    return cols;
  }
  const etapas = dados.etapas.length ? dados.etapas : ["Novo"];
  const cols = etapas.map((e) => ({ key: e, nome: rotulo(e), cor: corEtapa(e), etapa: (etapasInfo || []).find((x) => x.chave === e), itens: [] }));
  for (const x of lista) (cols.find((c) => c.key === x.etapa) || cols[0]).itens.push(x);
  return cols;
}

async function soltar(x, col, colEl) {
  const q = quadroAtual();
  if (q) {
    const ch = chaveTel(x.telefone); if (!ch) return;
    const atual = q.cartoes.find((k) => k.chave === ch);
    if (String(atual ? atual.coluna : "") === col.key) return;
    try {
      await rpc("ext_cartao_mover", { p_quadro: q.id, p_telefone: x.telefone, p_coluna: col.key ? Number(col.key) : null });
      q.cartoes = q.cartoes.filter((k) => k.chave !== ch);
      if (col.key) q.cartoes.push({ chave: ch, coluna: Number(col.key) });
    } catch (e) { aviso("topo", e.message, "erro"); }
    return desenharFunil();
  }
  const campo = quadroSel === "emp" ? "empreendimento" : "etapa";
  if ((x[campo] || "") === col.key) return;
  await salvar(colEl, x, campo, col.key);
  desenharFunil();
}

const ERROS_ETAPA = { so_admin: "Só o admin muda as etapas.", nome_vazio: "Escreva um nome.", nome_repetido: "Já existe uma etapa com esse nome.",
  maximo_12_etapas: "O máximo é 12 etapas.", etapa_de_fabrica: "Essa etapa é de fábrica: dá pra renomear, mas não apagar.",
  etapa_com_contatos: "Tem contatos nessa etapa. Arraste todos pra outra etapa e tente de novo." };
const erroEtapa = (m) => ERROS_ETAPA[m] || m;
function ferramentasEtapa(col) {
  if (!etapasInfo || !dados.sou_admin || !col.etapa) return null;
  const e = col.etapa, i = etapasInfo.indexOf(e);
  const b = (t, title, fn) => { const x = el("button", { textContent: t, title }); x.onclick = (ev) => { ev.stopPropagation(); fn(); }; return x; };
  const rodar = async (fn) => { try { await fn(); await carregar(); } catch (er) { aviso("topo", erroEtapa(er.message), "erro"); } };
  const mover = (d) => rodar(() => {
    const ids = etapasInfo.map((x) => x.id), j = i + d; if (j < 0 || j >= ids.length) return;
    [ids[i], ids[j]] = [ids[j], ids[i]];
    return rpc("ext_etapas_ordenar", { p_ids: ids });
  });
  return el("span", { className: "ferr" },
    b("◀", "Mover pra esquerda", () => mover(-1)),
    b("▶", "Mover pra direita", () => mover(1)),
    b("✎", "Renomear", () => { const n = (prompt("Nome da etapa:", e.nome) || "").trim(); if (n && n !== e.nome) rodar(() => rpc("ext_etapa_salvar", { p_id: e.id, p_nome: n, p_cor: e.cor })); }),
    b("🎨", "Trocar cor", () => rodar(() => rpc("ext_etapa_salvar", { p_id: e.id, p_nome: e.nome, p_cor: COR_ETAPA[(COR_ETAPA.indexOf(e.cor) + 1) % 7] }))),
    e.sistema ? null : b("🗑", "Apagar etapa", () => { if (confirm(`Apagar a etapa "${e.nome}"?`)) rodar(() => rpc("ext_etapa_apagar", { p_id: e.id })); }));
}

function ferramentasColuna(col) {
  if (col.etapa) return ferramentasEtapa(col);
  const q = quadroAtual(); if (!q || !col.coluna) return null;
  const c = col.coluna;
  const b = (t, title, fn) => { const e = el("button", { textContent: t, title }); e.onclick = (ev) => { ev.stopPropagation(); fn(); }; return e; };
  const salvarCol = async (nome, cor) => {
    try { await rpc("ext_coluna_salvar", { p_quadro: q.id, p_id: c.id, p_nome: nome, p_cor: cor, p_ordem: c.ordem }); await recarregarQuadros(); }
    catch (e) { aviso("topo", e.message, "erro"); }
  };
  return el("span", { className: "ferr" },
    b("✎", "Renomear", () => { const n = (prompt("Nome da coluna:", c.nome) || "").trim(); if (n && n !== c.nome) salvarCol(n, c.cor); }),
    b("🎨", "Trocar cor", () => salvarCol(c.nome, COR_ETAPA[(COR_ETAPA.indexOf(c.cor) + 1) % 7])),
    b("🗑", "Apagar coluna", async () => {
      if (!confirm(`Apagar a coluna "${c.nome}"? Os contatos voltam pra Entrada.`)) return;
      try { await rpc("ext_coluna_apagar", { p_quadro: q.id, p_id: c.id }); await recarregarQuadros(); } catch (e) { aviso("topo", e.message, "erro"); }
    }));
}

function desenharFunil() {
  const lista = visiveis();
  const cols = colunasDoQuadro(lista);
  $("funil").replaceChildren(...cols.map((col) => {
    const cards = el("div", { className: "cards" }, ...col.itens.map((x) => cartao(x)));
    const colEl = el("div", { className: "col" + (col.entrada ? " entrada" : "") },
      el("h4", {}, el("span", { className: "nm", textContent: col.nome }), ferramentasColuna(col), el("span", { className: "n", textContent: col.itens.length })), cards);
    colEl.style.setProperty("--c", col.cor);
    colEl.ondragover = (e) => { e.preventDefault(); colEl.classList.add("alvo"); };
    colEl.ondragleave = () => colEl.classList.remove("alvo");
    colEl.ondrop = (e) => { e.preventDefault(); colEl.classList.remove("alvo"); const x = arrastando; arrastando = null; if (x) soltar(x, col, colEl); };
    return colEl;
  }));
  contarSel();
  aviso("topo", lista.length ? "" : "Nenhum contato com esse filtro.");
}
function cartao(x) {
  const temp = (x.temperatura || "").toLowerCase();
  const c = el("div", { className: "card" + (selecionados.has(x.telefone) ? " sel" : ""), draggable: true, title: x.resumo || "" },
    el("b", { textContent: x.nome || fmtTel(x.telefone) }),
    x.nome ? el("small", { textContent: fmtTel(x.telefone) }) : null,
    el("div", { className: "tags" },
      x.empreendimento ? el("span", { className: "tag", textContent: x.empreendimento }) : null,
      temp ? el("span", { className: "tag " + temp, textContent: temp }) : null,
      x.dono ? el("span", { className: "tag", textContent: dados.sou_admin ? ((dados.corretores.find((k) => k.id === x.dono) || {}).nome || "dono") : x.dono }) : null),
    x.nota ? el("small", { textContent: "📝 " + x.nota }) : null,
    x.bloqueio ? el("small", { className: "nao", textContent: "sem disparo: " + motivo(x.bloqueio) }) : null);
  const conversa = el("button", { textContent: "💬 Conversa", title: "Abrir a conversa no WhatsApp" });
  conversa.onclick = (e) => { e.stopPropagation(); abrirConversa(x.telefone); };
  c.append(el("div", { className: "acoes" }, conversa, el("small", { textContent: fmtData(x.ultima) })));
  c.onclick = () => { selecionados.has(x.telefone) ? selecionados.delete(x.telefone) : selecionados.add(x.telefone); c.classList.toggle("sel"); contarSel(); };
  c.ondragstart = (e) => { arrastando = x; c.classList.add("arrasta"); e.dataTransfer.effectAllowed = "move"; e.dataTransfer.setData("text/plain", x.telefone); };
  c.ondragend = () => c.classList.remove("arrasta");
  return c;
}
function trocarVista(v) {
  vista = v;
  document.body.classList.toggle("vfunil", v === "funil");
  $("vTabela").classList.toggle("on", v === "tabela"); $("vFunil").classList.toggle("on", v === "funil");
  desenhar();
}
$("vTabela").onclick = () => trocarVista("tabela");
$("vFunil").onclick = () => trocarVista("funil");
function abrirPeloLink() {
  const v = Q.get("v");
  if (v === "funil") trocarVista("funil");
  if (v === "disparo" || v === "anuncios") {
    $("bDisparo").click();
    if (v === "anuncios") { const a = document.querySelector('.aba[data-modo="anuncios"]'); if (a) a.click(); }
  }
}
if (vista === "funil") document.body.classList.add("vfunil");

function contarSel() { $("nSel").textContent = selecionados.size + " selecionado" + (selecionados.size === 1 ? "" : "s"); }

// ---------- barra ----------
let tBusca;
$("fBusca").oninput = () => { clearTimeout(tBusca); tBusca = setTimeout(carregar, 400); };
$("fEmp").onchange = carregar; $("fEtapa").onchange = carregar; $("fSoPode").onchange = desenhar;
$("bAtualizar").onclick = carregar;
$("bTodos").onclick = () => { visiveis().forEach((x) => selecionados.add(x.telefone)); desenhar(); };
$("bLimpar").onclick = () => { selecionados.clear(); desenhar(); };
document.querySelectorAll("th[data-o]").forEach((th) => th.onclick = () => {
  ordem = { campo: th.dataset.o, desc: ordem.campo === th.dataset.o ? !ordem.desc : false }; desenhar();
});

$("bCsv").onclick = () => {
  const cols = [["nome", "Nome"], ["telefone", "Telefone"], ["empreendimento", "Empreendimento"], ["etapa", "Etapa"], ["dono", "Dono"],
    ["nota", "Última nota"], ["renda", "Renda"], ["fgts", "FGTS"], ["interesse", "Interesse"], ["temperatura", "Temperatura"],
    ["resumo", "Resumo"], ["bloqueio", "Bloqueio disparo"], ["ultima", "Último contato"]];
  const lista = selecionados.size ? visiveis().filter((x) => selecionados.has(x.telefone)) : visiveis();
  const esc = (v) => { let s = v == null ? "" : String(v); if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; return /[";\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
  const csv = "\uFEFF" + [cols.map((c) => c[1]).join(";"),
    ...lista.map((x) => cols.map(([k]) => esc(k === "ultima" ? fmtData(x[k]) : k === "bloqueio" ? (x[k] ? motivo(x[k]) : "pode") : x[k])).join(";"))].join("\r\n");
  const a = el("a", { href: URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" })), download: "contatos-" + new Date().toISOString().slice(0, 10) + ".csv" });
  a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 5000);
  aviso("topo", lista.length + " contatos exportados" + (selecionados.size ? " (só os selecionados)." : "."));
};

// ---------- painéis ----------
const abrir = (id) => { document.querySelectorAll(".painel").forEach((p) => p.classList.toggle("on", p.id === id)); };
document.querySelectorAll("[data-fechar]").forEach((b) => b.onclick = () => abrir(null));
$("bImportar").onclick = () => { abrir("pImportar"); $("iEmp").value = $("fEmp").value && $("fEmp").value !== "__sem__" ? $("fEmp").value : ""; };
$("bDisparo").onclick = () => { abrir("pDisparo"); atualizarPublico(); montarListaEmp(); listarCampanhas(); };

// ---------- importar ----------
function mostrarImportacao(r) {
  importacao = r;
  const n = r.contatos.length;
  $("iEnviar").disabled = !n;
  const ex = r.contatos.slice(0, 6).map((c) => [c.nome || "(sem nome)", c.telefone, c.empreendimento].filter(Boolean).join(" · ")).join("\n");
  $("iPrevia").replaceChildren(el("div", { className: "msg", textContent: n + " linhas com telefone." + (n > 2000 ? " Vou mandar em partes de 2000." : "") }),
    el("div", { className: "previa", textContent: ex + (n > 6 ? "\n…" : "") }));
}
$("iArq").onchange = async () => {
  const f = $("iArq").files[0]; if (!f) return;
  aviso("iMsg", "Lendo " + f.name + "…");
  try { mostrarImportacao(await LeitorPlanilha.lerArquivo(f)); aviso("iMsg", ""); }
  catch (e) { importacao = null; $("iEnviar").disabled = true; aviso("iMsg", e.message, "erro"); }
};
$("iColar").oninput = () => {
  const t = $("iColar").value; if (!t.trim()) return;
  try { mostrarImportacao(LeitorPlanilha.lerColado(t)); aviso("iMsg", ""); }
  catch (e) { importacao = null; $("iEnviar").disabled = true; aviso("iMsg", e.message, "erro"); }
};
$("iEnviar").onclick = async () => {
  if (!importacao) return;
  const b = $("iEnviar"); b.disabled = true;
  const soma = { novos: 0, atualizados: 0, ja_estavam: 0, invalidos: 0, de_outro: 0, pediram_sair: 0 }; const tels = [];
  try {
    for (let i = 0; i < importacao.contatos.length; i += 2000) {
      aviso("iMsg", "Importando " + Math.min(i + 2000, importacao.contatos.length) + " de " + importacao.contatos.length + "…");
      const r = await rpc("ext_planilha_importar", { p_linhas: importacao.contatos.slice(i, i + 2000), p_empreendimento: $("iEmp").value.trim() || null, p_sobrescrever: $("iSobre").checked });
      Object.keys(soma).forEach((k) => soma[k] += r[k] || 0); tels.push(...(r.telefones || []));
    }
    tels.forEach((t) => selecionados.add(t));
    aviso("iMsg", `Pronto. ${soma.novos} novos, ${soma.atualizados} atualizados, ${soma.ja_estavam} já estavam.` +
      (soma.invalidos ? ` ${soma.invalidos} telefones inválidos.` : "") + (soma.de_outro ? ` ${soma.de_outro} são de outro corretor (não mexi).` : "") +
      (soma.pediram_sair ? ` ${soma.pediram_sair} pediram SAIR e não recebem disparo.` : "") +
      `\n${tels.length} ficaram selecionados. Clique em Disparo pra montar a campanha.`);
    $("iColar").value = ""; $("iArq").value = ""; importacao = null; $("iPrevia").replaceChildren();
    await carregar();
  } catch (e) { aviso("iMsg", e.message, "erro"); b.disabled = false; }
};

// ---------- caixa de foto (colar, arrastar ou escolher) ----------
function reduzir(arquivo) {
  return new Promise((ok, falha) => {
    if (!arquivo || !/^image\//.test(arquivo.type)) return falha(new Error("Isso não é uma imagem."));
    const img = new Image(); const url = URL.createObjectURL(arquivo);
    img.onload = () => {
      const max = 1600, k = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement("canvas"); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
      const g = c.getContext("2d"); g.fillStyle = "#fff"; g.fillRect(0, 0, c.width, c.height); g.drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url); ok(c.toDataURL("image/jpeg", 0.85));
    };
    img.onerror = () => { URL.revokeObjectURL(url); falha(new Error("Não consegui abrir a imagem.")); };
    img.src = url;
  });
}
const caixas = [];
function caixaFoto(id, msgId) {
  const caixa = $(id); const arq = el("input", { type: "file", accept: "image/*", hidden: true }); caixa.after(arq);
  const tirar = el("button", { className: "s", textContent: "Remover foto", hidden: true }); arq.after(tirar);
  const obj = { url: null, caixa };
  const vazia = () => { caixa.replaceChildren("Cole a foto aqui (Ctrl+V)", el("br"), "ou clique pra escolher"); tirar.hidden = true; };
  obj.definir = (url) => { obj.url = url || null; if (url) { caixa.replaceChildren(el("img", { src: url, alt: "foto" })); tirar.hidden = false; } else vazia(); };
  obj.usar = async (arquivo) => {
    if (!arquivo) return;
    try {
      caixa.textContent = "Enviando foto…";
      const dataUrl = await reduzir(arquivo);
      const r = await bg({ tipo: "foto", corretor: dados.eu, dataUrl });
      if (!r.ok) throw new Error(r.erro);
      obj.url = r.url; caixa.replaceChildren(el("img", { src: dataUrl, alt: "foto" })); tirar.hidden = false;
    } catch (e) { obj.url = null; vazia(); aviso(msgId, e.message, "erro"); }
  };
  caixa.onclick = () => arq.click();
  arq.onchange = () => { obj.usar(arq.files[0]); arq.value = ""; };
  caixa.addEventListener("paste", (e) => { const it = [...e.clipboardData.items].find((i) => i.type.startsWith("image/")); if (it) { e.preventDefault(); e.stopPropagation(); obj.usar(it.getAsFile()); } });
  caixa.ondragover = (e) => e.preventDefault();
  caixa.ondrop = (e) => { e.preventDefault(); obj.usar(e.dataTransfer.files[0]); };
  tirar.onclick = () => obj.definir(null);
  vazia(); caixas.push(obj); return obj;
}
const fotoUnica = caixaFoto("dFoto", "dMsg");
const fotoAnuncio = caixaFoto("aFoto", "aMsg");
// Ctrl+V fora da caixa (sem estar digitando) cai na caixa visível
document.addEventListener("paste", (e) => {
  if (/TEXTAREA|INPUT/.test(document.activeElement.tagName)) return;
  const alvo = caixas.find((c) => c.caixa.offsetParent !== null); if (!alvo) return;
  const it = [...e.clipboardData.items].find((i) => i.type.startsWith("image/")); if (it) { e.preventDefault(); alvo.usar(it.getAsFile()); }
});

// ---------- abas do disparo ----------
let modelos = [];
document.querySelectorAll(".aba").forEach((b) => b.onclick = () => {
  document.querySelectorAll(".aba").forEach((x) => x.classList.toggle("on", x === b));
  const m = { emp: "mEmp", unico: "mUnico", anuncios: "mAnuncios" }[b.dataset.modo];
  document.querySelectorAll(".modo").forEach((x) => x.classList.toggle("on", x.id === m));
  if (b.dataset.modo === "anuncios") carregarModelos();
  if (b.dataset.modo === "emp") montarListaEmp();
});
const nomeEmp = (e) => e || "Sem empreendimento";
const temAnuncio = (e) => modelos.some((m) => m.empreendimento.toLowerCase() === (e || "").toLowerCase());

// ---------- cada um com seu anúncio ----------
async function montarListaEmp() {
  try { modelos = await rpc("ext_modelo_listar", {}) || []; } catch (e) { aviso("eMsg", e.message, "erro"); }
  const todos = el("label", {}, el("input", { type: "checkbox", id: "eTodos", checked: true }), " Todos");
  const itens = dados.grupos.map((g) => {
    const ck = el("input", { type: "checkbox", value: g.empreendimento || "", className: "eGrupo" });
    const marca = temAnuncio(g.empreendimento) ? el("span", { className: "tem", textContent: " anúncio próprio" })
      : el("span", { className: "falta", textContent: temAnuncio("") ? " usa o geral" : " sem anúncio" });
    return el("label", {}, ck, " " + nomeEmp(g.empreendimento) + " (" + g.total + ")", marca);
  });
  $("eLista").replaceChildren(todos, el("br"), ...itens);
  const sync = () => { const algum = [...document.querySelectorAll(".eGrupo")].some((c) => c.checked); $("eTodos").checked = !algum; };
  document.querySelectorAll(".eGrupo").forEach((c) => c.onchange = sync);
  $("eTodos").onchange = () => { if ($("eTodos").checked) document.querySelectorAll(".eGrupo").forEach((c) => c.checked = false); else sync(); };
  $("eSoSelLbl").hidden = !selecionados.size; $("eSoSel").checked = selecionados.size > 0;
  $("eSoSelLbl").lastChild.textContent = ` só os ${selecionados.size} contatos selecionados na planilha`;
}
function argsEmp(criar) {
  const marcados = [...document.querySelectorAll(".eGrupo")].filter((c) => c.checked).map((c) => c.value);
  return { p_nome: $("eNome").value.trim(), p_empreendimentos: $("eTodos").checked ? null : marcados,
    p_telefones: $("eSoSel").checked && selecionados.size ? [...selecionados] : null,
    p_limite_dia: Math.min(1000, Math.max(1, Number($("eLimite").value) || 20)), p_aceite_risco: $("eAceite").checked, p_criar: criar };
}
function resumoGrupos(r) {
  const linhas = r.grupos.map((g) => `${nomeEmp(g.empreendimento)}: ${g.total}` + (g.anuncio === "proprio" ? "" : g.anuncio === "geral" ? " (anúncio geral)" : " (SEM anúncio, não vai)"));
  return linhas.join("\n") + `\n\nTotal que vai receber: ${r.total}.` + (r.sem_anuncio ? ` ${r.sem_anuncio} ficam de fora por falta de anúncio (crie na aba Anúncios).` : "");
}
$("ePrevia").onclick = async () => {
  try { const r = await rpc("ext_disparo_por_empreendimento", argsEmp(false)); aviso("eMsg", r.grupos.length ? resumoGrupos(r) : "Ninguém pode receber com essa escolha."); }
  catch (e) { aviso("eMsg", e.message, "erro"); }
};
$("eCriar").onclick = async () => {
  const a = argsEmp(true);
  if (!a.p_nome) return aviso("eMsg", "Dê um nome pra campanha.", "erro");
  if (!a.p_aceite_risco) return aviso("eMsg", "Marque o aceite do risco.", "erro");
  if (!confirmaVolume("eLimite")) return;
  const b = $("eCriar"); b.disabled = true;
  try {
    const r = await rpc("ext_disparo_por_empreendimento", a);
    const n = r.grupos.filter((g) => g.campanha_id).length;
    aviso("eMsg", `${n} campanha${n === 1 ? "" : "s"} criada${n === 1 ? "" : "s"} em rascunho, uma por empreendimento.\n` + resumoGrupos(r) + "\n\nConfira e clique em Ativar em cada uma.");
    listarCampanhas();
  } catch (e) { aviso("eMsg", e.message, "erro"); }
  b.disabled = false;
};

// ---------- anúncios ----------
async function carregarModelos() {
  try {
    modelos = await rpc("ext_modelo_listar", {}) || [];
    const nomes = [...new Set([...empreendimentos, ...dados.grupos.map((g) => g.empreendimento).filter(Boolean)])].sort((a, b) => a.localeCompare(b));
    const sel = $("aEmp"), atual = sel.value;
    sel.replaceChildren(new Option("Geral (todos sem anúncio próprio)", ""), ...nomes.map((n) => new Option(n + (temAnuncio(n) ? "  ✓" : ""), n)));
    sel.value = nomes.includes(atual) ? atual : "";
    $("aLista").replaceChildren(el("div", { className: "previa", textContent: modelos.length
      ? "Com anúncio: " + modelos.map((m) => m.empreendimento || "Geral").join(", ")
      : "Nenhum anúncio ainda. Comece pelo Geral." }));
    abrirModelo();
  } catch (e) { aviso("aMsg", e.message, "erro"); }
}
function abrirModelo() {
  const m = modelos.find((x) => x.empreendimento.toLowerCase() === $("aEmp").value.toLowerCase());
  $("aMsg1").value = m ? m.msg1 : ""; $("aMsg2").value = m ? (m.msg2 || "") : ""; fotoAnuncio.definir(m ? m.midia_url : null);
  $("aApagar").hidden = !m; aviso("aMsg", "");
}
$("aEmp").onchange = abrirModelo;
$("aSalvar").onclick = async () => {
  if (!$("aMsg1").value.trim()) return aviso("aMsg", "Escreva pelo menos a mensagem 1.", "erro");
  try {
    await rpc("ext_modelo_salvar", { p_empreendimento: $("aEmp").value, p_msg1: $("aMsg1").value, p_msg2: $("aMsg2").value || null, p_midia_url: fotoAnuncio.url });
    aviso("aMsg", "Anúncio salvo."); await carregarModelos();
  } catch (e) { aviso("aMsg", e.message, "erro"); }
};
$("aApagar").onclick = async () => {
  if (!confirm("Apagar o anúncio de " + ($("aEmp").value || "Geral") + "?")) return;
  try { await rpc("ext_modelo_apagar", { p_empreendimento: $("aEmp").value }); aviso("aMsg", "Apagado."); await carregarModelos(); }
  catch (e) { aviso("aMsg", e.message, "erro"); }
};

// ---------- alerta de volume (a decisão é do corretor) ----------
function alertaVolume(inputId, alertaId, porEmp) {
  const n = Number($(inputId).value) || 0, box = $(alertaId);
  const nivel = n > 100 ? "Muito alto: com esse volume o WhatsApp costuma bloquear o número em poucos dias." :
                n > 40 ? "Acima de 40 por dia o risco de bloqueio do número sobe bastante." : "";
  box.hidden = !nivel;
  box.textContent = nivel ? nivel + (porEmp ? " Esse número vale pra cada empreendimento, e eles somam no mesmo WhatsApp." : "") + " A decisão é sua." : "";
  return !!nivel;
}
$("eLimite").oninput = () => alertaVolume("eLimite", "eAlerta", true);
$("dLimite").oninput = () => alertaVolume("dLimite", "dAlerta", false);
const confirmaVolume = (inputId) => (Number($(inputId).value) || 0) <= 40 ||
  confirm("Você escolheu " + $(inputId).value + " por dia. Acima de 40 o risco de bloqueio do número é alto. Criar mesmo assim?");

// ---------- mensagem única ----------
const filtroDisparo = () => selecionados.size
  ? { telefones: [...selecionados] }
  : Object.fromEntries(Object.entries({ campanha: $("fEmp").value && $("fEmp").value !== "__sem__" ? $("fEmp").value : null,
      etapas: $("fEtapa").value ? [$("fEtapa").value] : null }).filter(([, v]) => v));

function atualizarPublico() {
  const f = filtroDisparo();
  $("dPublico").textContent = selecionados.size
    ? `Público: os ${selecionados.size} contatos selecionados na planilha (quem estiver bloqueado é pulado).`
    : "Público: ninguém selecionado. Vai usar o filtro da planilha" + (f.campanha ? ` (empreendimento ${f.campanha})` : "") + (f.etapas ? ` (etapa ${f.etapas[0]})` : "") + ". Selecione contatos pra ser mais preciso.";
}
$("dPrevia").onclick = async () => {
  try {
    const r = await rpc("ext_disparo_previa", { p_filtro: filtroDisparo() });
    const dias = Math.ceil(r.total / Math.max(1, Number($("dLimite").value) || 20));
    aviso("dMsg", `${r.total} vão receber.` + (r.amostra.length ? ` Ex.: ${r.amostra.join(", ")}.` : "") + (r.total ? ` Com o limite atual, leva uns ${dias} dia${dias > 1 ? "s" : ""} úteis.` : ""));
  } catch (e) { aviso("dMsg", e.message, "erro"); }
};
$("dCriar").onclick = async () => {
  const nome = $("dNome").value.trim(), m1 = $("dMsg1").value.trim();
  if (!nome || !m1) return aviso("dMsg", "Preencha o nome e a mensagem 1.", "erro");
  if (!$("dAceite").checked) return aviso("dMsg", "Marque o aceite do risco.", "erro");
  if (!confirmaVolume("dLimite")) return;
  const b = $("dCriar"); b.disabled = true;
  try {
    const r = await rpc("ext_disparo_criar", { p_nome: nome, p_filtro: filtroDisparo(), p_msg1: m1, p_msg2: $("dMsg2").value.trim() || null,
      p_midia_url: fotoUnica.url, p_limite_dia: Math.min(1000, Math.max(1, Number($("dLimite").value) || 20)), p_aceite_risco: true });
    aviso("dMsg", `Campanha criada com ${r.total} contatos, em rascunho. Confira e clique em Ativar quando quiser começar.`);
    listarCampanhas();
  } catch (e) { aviso("dMsg", e.message, "erro"); }
  b.disabled = false;
};
async function listarCampanhas() {
  try {
    const l = await rpc("ext_disparo_listar", {});
    $("dCamps").replaceChildren(...(l || []).map((c) => {
      const acoes = [];
      const bt = (t, st, cls) => { const b = el("button", { className: cls || "s", textContent: t }); b.onclick = async () => {
        if (st === "cancelada" && !confirm("Cancelar a campanha " + c.nome + "? Os pendentes não serão enviados.")) return;
        try { await rpc("ext_disparo_status", { p_id: c.id, p_status: st }); listarCampanhas(); } catch (e) { aviso("dMsg", e.message, "erro"); } }; return b; };
      if (c.status === "rascunho" || c.status === "pausada") acoes.push(bt("Ativar", "ativa", " "));
      if (c.status === "ativa") acoes.push(bt("Pausar", "pausada"));
      if (!["concluida", "cancelada"].includes(c.status)) acoes.push(bt("Cancelar", "cancelada", "w"));
      return el("div", { className: "camp" },
        el("b", { textContent: c.nome }), " ", el("small", { textContent: "· " + c.status + " · " + c.limite_dia + "/dia · " + fmtData(c.criado_em) }),
        el("div", { textContent: `${c.enviados} enviados, ${c.pendentes} na fila, ${c.pulados} pulados, ${c.falhas} falhas` }),
        el("div", {}, ...acoes.flatMap((a) => [a, " "])));
    }));
    if (!(l || []).length) $("dCamps").textContent = "Nenhuma campanha ainda.";
  } catch (e) { aviso("dMsg", e.message, "erro"); }
}

carregar();
